'use strict';

angular.module('app', ['ui.router', 'ngCookies', 'validation', 'ngAnimate']);
